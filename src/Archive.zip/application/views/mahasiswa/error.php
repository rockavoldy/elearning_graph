<div class="col-xl-12 col-lg-7">
    <div class="card shadow mb-4">
      <!-- Card Body -->
       <div class="card-body">
        <h3 style="align: justify;">Dimohon untuk menyelesaikan tugas terlebih dahulu sebelum ke halaman evaluasi.</h3> 
          
       </div>
    </div>
</div>