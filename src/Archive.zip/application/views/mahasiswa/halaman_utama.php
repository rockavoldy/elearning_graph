   <!-- Begin Page Content -->
   <div class="container-fluid">

<!-- Page Heading -->


<div class="col-xl-12 col-lg-7">
    <div class="card shadow mb-4">
      <!-- Card Body -->
       <div class="card-body" style="text-align:justify; ">
        <h3>Selamat Datang <?php echo $this->session->userdata('nama'); ?>, di media pembelajaran WEB Kelasku.</h3> 
          <p>Dalam  media pembelajaran ini akan dibahas : Pengertian dari Graf, Jenis - Jenis Graf, Istilah yang ada didalam Graf, Representasi Graf, Graf euler dan Graf Hamilton. </p>
        
        <p style="font-size: 20px;">Tujuan Pembelajaran :</p>
        <p> Setelah menggunakan media pembelajaran ini mahasiswa diharapkan dapat memiliki pengetahuan,  pemahaman dari : Pengertian dari Graf, Jenis - Jenis Graf, Istilah yang ada didalam Graf, Representasi Graf, Graf euler dan Graf Hamilton. Serta mampu untuk menerapkan teori Graf dalam masalah nyata.</p>
     
        <p style="font-size: 20px;">Petunjuk Penggunaan Media WEB Kelasku :     </p>
        <p>1. Masuk ke halaman materi yang berada di sisi bar</p>
        <p>2. Klik pada video materi yang berada di halaman materi</p>
        <p>3. Setelah selesai, kerjakan latihan soal yang berada di bawah video materi</p>
        <p>4. Selesaikan semua video materi dan latihan soal untuk membuka halaman evaluasi</p>
        <p>5. Jika semua sudah selesai, pergi ke halaman evaluasi untuk menyelesaikan tes akhir</p>
        </div>
    </div>
</div>

</div>

<!-- /.container-fluid -->
