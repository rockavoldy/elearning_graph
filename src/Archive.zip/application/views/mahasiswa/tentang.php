   <!-- Begin Page Content -->
<div class="container-fluid">
<div class="card mb-4 col-lg-12" >
  <div class="row no-gutters">
      <div class="col-md-3">
        <img src="<?php echo base_url('/assets/img/profile.jpeg'); ?>" class="card-img" style="width:200px; height:200px; object-fit: cover;margin-top : 40px;margin-bottom : 40px;margin-left:10px; margin-right: 10px;" >
      </div>
      <div class="col-md-9">
        <div class="card-body" style="font-family: sans-serif; ">
            <h2 class="card-title" >Tentang</h2>
            <table style ">
                <tr>
                    <td>Nama</td>
                    <td>&nbsp: Muhammad Rafli</td>
                    
                </tr>
                <tr>
                    <td>NIM</td>
                    <td>&nbsp: 1600347</td>
                </tr>
                <tr>
                    <td>Prodi</td>
                    <td>&nbsp: Pendidikan Ilmu Komputer</td>
                </tr>
                <tr>
                    <td>Fakultas</td>
                    <td>&nbsp: Pendidikan Matematika dan Ilmu Pengetahuan Alam</td>
                </tr>
                
                
            </table> 
            <br>
            <P>Aplikasi ini gunakan untuk keperluan skripsi dengan judul <strong>"IMPLEMTASI BERPIKIR KOMPUTASI PADA MATA KULIAH STRUKTUR DATA DENGAN MODEL PROBLEM BASED LEARNING"<strong>.</P>
        </div>
      </div>
  </div>  

</div>

<!-- /.container-fluid -->

</div>
<!-- End of Main Content -->